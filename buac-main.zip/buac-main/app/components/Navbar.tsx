"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/tours", label: "Tours" },
    { href: "/activities", label: "Activities" },
    { href: "/about", label: "About" },
    { href: "/gallery", label: "Gallery" },
    { href: "/contact", label: "Contact" },
  ];

  const isActive = (path: string) => pathname === path;

  return (
    <>
      <nav
        className={`absolute top-0 w-full z-50 transition-all duration-500 bg-black/80 backdrop-blur-xl shadow-lg shadow-accent/10`}
      >
        <div className=" px-4 sm:px-6 lg:px-12">
          <div className="flex justify-between items-center h-20 lg:h-16">
            <Link
              href="/"
              className="flex items-center gap-3 group z-50 relative"
            >
              <div className="relative">
                <Image
                  src="/assets/logos/buac.webp"
                  alt="BUAC Logo"
                  width={50}
                  height={50}
                  className="transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-accent/30 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
              </div>
              <div className="hidden md:block">
                <h1 className="text-2xl lg:text-3xl font-bebasNeue text-zinc-100 leading-tight tracking-wider">
                  BRAC UNIVERSITY
                  <span className="text-accent"> ADVENTURE CLUB</span>
                </h1>
              </div>
              <div className="md:hidden">
                <h1 className="text-4xl font-bebasNeue text-zinc-100 leading-tight tracking-wider">
                  BUAC
                </h1>
              </div>
            </Link>

            <div className="hidden lg:flex items-center gap-8">
              <ul className="flex items-center gap-1">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className={`relative px-5 py-2 text-sm font-medium tracking-widest uppercase transition-all duration-300 group ${
                        isActive(link.href)
                          ? "text-accent"
                          : "text-zinc-100 hover:text-accent"
                      }`}
                    >
                      {link.label}
                      <span
                        className={`absolute bottom-0 left-0 w-full h-0.5 bg-accent transform origin-left transition-transform duration-300 ${
                          isActive(link.href)
                            ? "scale-x-100"
                            : "scale-x-0 group-hover:scale-x-100"
                        }`}
                      ></span>
                    </Link>
                  </li>
                ))}
              </ul>

              <Link
                href="/recruitment"
                className="relative px-6 py-3 text-sm font-bold tracking-wider uppercase bg-accent text-text-secondary rounded-full overflow-hidden group transition-all duration-300 hover:shadow-lg hover:shadow-accent/50 hover:scale-105"
              >
                <span className="relative z-10">Join Us</span>
              </Link>
            </div>

            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden relative w-10 h-10 flex flex-col items-center justify-center gap-1.5 z-50 group"
              aria-label="Toggle menu"
            >
              <span
                className={`w-7 h-0.5 bg-zinc-100 transition-all duration-300 ${
                  isOpen
                    ? "rotate-45 translate-y-2 bg-accent"
                    : "group-hover:w-6"
                }`}
              ></span>
              <span
                className={`w-7 h-0.5 bg-zinc-100 transition-all duration-300 ${
                  isOpen ? "opacity-0" : "group-hover:w-5"
                }`}
              ></span>
              <span
                className={`w-7 h-0.5 bg-zinc-100 transition-all duration-300 ${
                  isOpen
                    ? "-rotate-45 -translate-y-2 bg-accent"
                    : "group-hover:w-6"
                }`}
              ></span>
            </button>
          </div>
        </div>
      </nav>

      <div
        className={`fixed inset-0 bg-black/95 backdrop-blur-xl z-40 lg:hidden transition-opacity duration-500 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
        </div>

        <div className="relative h-full flex flex-col items-center justify-center px-8">
          <ul className="space-y-6 text-center">
            {navLinks.map((link, index) => (
              <li
                key={link.href}
                className={`transform transition-all duration-500 ${
                  isOpen
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <Link
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className={`block text-4xl md:text-5xl font-bebasNeue tracking-wider transition-all duration-300 ${
                    isActive(link.href)
                      ? "text-accent scale-110"
                      : "text-zinc-100 hover:text-accent hover:scale-110"
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            ))}
            <li
              className={`transform transition-all duration-500 pt-8 ${
                isOpen
                  ? "translate-y-0 opacity-100"
                  : "translate-y-10 opacity-0"
              }`}
              style={{ transitionDelay: "400ms" }}
            >
              <Link
                href="/recruitment"
                onClick={() => setIsOpen(false)}
                className="inline-block px-10 py-4 text-xl font-bold tracking-wider uppercase bg-accent text-black rounded-full hover:shadow-lg hover:shadow-accent/50 hover:scale-105 transition-all duration-300"
              >
                Join Us
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default Navbar;
