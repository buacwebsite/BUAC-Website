"use client";

import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useRef } from "react";

gsap.registerPlugin(ScrollTrigger);

const FootprintRoadmap = () => {
  const strokeContainerRef = useRef<HTMLDivElement>(null);
  const strokeRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    const strokeEl = strokeRef.current;
    if (!strokeEl) return;
    const path = strokeEl.querySelector("path");
    if (!path) return;
    const pathLength = path.getTotalLength();

    path.style.strokeDasharray = `${pathLength}`;
    path.style.strokeDashoffset = `${pathLength}`;

    gsap.to(path, {
      strokeDashoffset: 0,
      ease: "none",
      scrollTrigger: {
        trigger: strokeContainerRef.current,
        start: "top top",
        end: "bottom bottom",
        scrub: true,
        // markers: true,
        onUpdate: () => {
          console.log("ScrollTrigger updated", pathLength);
        },
      },
    });
  });
  return (
    <div className="h-[1080*3]" ref={strokeContainerRef}>
      <div
        className="footprint-svg absolute top-0 w-full h-full"
        ref={strokeRef}
      >
        <svg
          id="Layer_2"
          data-name="Layer 2"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 2383.79 3658.09"
        >
          <g id="Layer_1-2" data-name="Layer 1">
            <path d="m1242.4.18c-260.65,101.09-491.3,290.75-592.12,557.27-71.24,188.34-70.65,423.87,55.86,589.52,67.61,88.52,165.07,147.63,268.32,185.98,148.66,55.22,304.74,66.21,461.18,80.48,147.17,13.43,295.08,31.81,438.45,68.65,96.66,24.84,193.48,58.6,276.75,114.78,66.27,44.7,120.39,104.32,155.98,176.07,37.57,75.75,54.51,160.13,63.21,243.69,10.51,100.99,9.2,202.83,8.42,304.22-.82,106.23-3.67,212.51-12.27,318.42-17.5,215.66-57.11,439.01-167.02,628.5-53.84,92.83-125.39,175.09-213.31,237.08-97.9,69.03-212.11,110.72-329.64,131.21-125.8,21.93-253.98,17.65-381.12,15.6-133.95-2.16-267.88-6.44-401.66-13.4-141.39-7.35-282.77-17.44-423.41-33.89-114.75-13.42-231.28-29.27-342.19-62.73-35.93-10.84-72.09-23.64-104.11-43.53-2.74-1.7-5.25,2.62-2.52,4.32,75.2,46.7,170.82,63.46,256.48,78.99,129.38,23.46,260.62,36.81,391.62,47.25,261.3,20.84,523.88,29.09,785.98,29.41,132.71.16,266.39-15.27,390.98-63.07,101.23-38.83,193.42-98.77,268.07-177.58,147.1-155.29,216.83-366.39,251.87-573.37,35.47-209.55,38.06-423.15,37.57-635.15-.4-169.99-8.12-361.38-112.32-504.17-113.67-155.76-315.93-214.48-496.11-250.06-156.43-30.9-314.57-42.18-472.97-57.43-145.75-14.03-295.94-43-425.65-113.95-95.6-52.29-175.23-129.62-220.35-229.69-43.31-96.05-56-207.47-45.4-311.75,26.27-258.63,196.37-484.66,409.64-623.7,70.07-45.68,145.22-82.94,223.16-113.17,2.97-1.15,1.68-5.99-1.33-4.82h0Z" />
          </g>
        </svg>
      </div>
    </div>
  );
};

export default FootprintRoadmap;
