"use client";

import { createContext, useContext, useState, ReactNode } from "react";
import axios from "axios";

interface AuthContextType {
  auth: boolean;
  setAuth: (value: boolean) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  auth: false,
  setAuth: () => {},
  logout: async () => {},
});

export function AuthProvider({
  children,
  initialAuth,
}: {
  children: ReactNode;
  initialAuth: boolean;
}) {
  const [auth, setAuth] = useState(initialAuth);

  const logout = async () => {
    await axios.get("/api/admin/logout");
    setAuth(false);
    window.location.reload();
  };

  return (
    <AuthContext.Provider value={{ auth, setAuth, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
