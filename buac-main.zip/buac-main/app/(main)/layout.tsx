import type { Metadata } from "next";
import { Poppins, Bebas_Neue } from "next/font/google";
import "../globals.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { AuthProvider } from "../context/AuthProvider";
import { cookies } from "next/headers";
import jwt from "jsonwebtoken";
import { env } from "../../env";
import { ReactLenis } from "lenis/react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { EditorProvider } from "../context/EditorContext";

gsap.registerPlugin(ScrollTrigger);

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

const bebasNeue = Bebas_Neue({
  variable: "--font-bebasNeue",
  subsets: ["latin"],
  weight: ["400"],
});

export const metadata: Metadata = {
  title: "BUAC",
  description: "BUAC - BRAC University Adventure Club",
};

export default async function MainLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies();
  const token = cookieStore.get("admin-token")?.value ?? "";
  let authenticated = false;

  try {
    const payload = jwt.verify(token, env.adminJwtSecret) as {
      sub: string;
      role: string;
      iat: number;
      exp: number;
    };
    authenticated = payload?.role === "admin";
  } catch {
    authenticated = false;
  }
  return (
    <div
      className={`${poppins.variable} ${bebasNeue.variable} bg-background text-text min-h-screen antialiased`}
    >
      <ReactLenis root />
      <AuthProvider initialAuth={authenticated}>
        <EditorProvider>
          <Navbar />
          <div className="pt-16 overflow-hidden">{children}</div>
          <Footer />
        </EditorProvider>
      </AuthProvider>
    </div>
  );
}
